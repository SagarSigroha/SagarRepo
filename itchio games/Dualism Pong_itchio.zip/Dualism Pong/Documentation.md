Dualism Pong : Assignment 1

1. Personal Interpretation of Dualism

Dualism means that there are two opposite but connected forces in the world, like light and dark, good and bad, or mind and body. These forces need each other and their interaction creates balance. I see dualism as two things that are different but linked, always affecting each other and creating movement or tension between them.

2. Changes to the Pong Rules

In my version of Pong:

The two paddles represent opposite forces (blue and orange).

The ball periodically changes which player controls it.

The player controlling the ball cannot move their paddle, showing that power comes with limits.

When the ball hits a paddle, it releases sparkles, and the ball leaves a glowing trail, showing energy transfer.

The game ends when a player reaches 10 points, and pressing ENTER restarts the game.

3. How the Rules Show Dualism

The game shows dualism because the two paddles are opposing forces that interact constantly through the ball. Control switches between players, showing balance and tension. The sparkles and glowing trails represent energy moving between the two sides. The rule that a player cannot move the paddle while controlling the ball shows that power is limited and connected to its opposite. Overall, the gameplay is about interaction, balance, and constant change between two opposing forces, which is the essence of dualism.